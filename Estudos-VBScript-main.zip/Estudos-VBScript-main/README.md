# Estudos de Visual Basic Script
